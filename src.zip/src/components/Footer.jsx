import React from 'react'

function Footer() {
  return (
    <div className="w-full h-12 bg-blue-500 text-center p-2">
    <span className="font-serif text-white text-[20px]"> &copy; 2025 by Dveloper: RJ Sami</span>
  </div>
  
  )
}

export default Footer